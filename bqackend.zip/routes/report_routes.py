from flask import Blueprint, request, jsonify
from models import Bill, Service, ServiceGroup, Staff, Customer, Expense, Product, Membership
from datetime import datetime, timedelta
from mongoengine.errors import DoesNotExist
from bson import ObjectId
from utils.auth import require_auth, require_role
from utils.branch_filter import get_selected_branch
from utils.date_utils import get_ist_date_range

report_bp = Blueprint('report', __name__)

def get_safe_customer_info(customer_ref):
    """Safely extract customer info, handling deleted references"""
    if not customer_ref:
        return {'name': 'Walk-in', 'mobile': None, 'id': None}
    
    try:
        # Try to reload if it's a DBRef
        if hasattr(customer_ref, 'reload'):
            try:
                customer_ref.reload()
            except:
                # Customer deleted, return default
                return {'name': 'Walk-in', 'mobile': None, 'id': None}
        
        # Check if customer has required attributes
        if hasattr(customer_ref, 'first_name'):
            return {
                'name': f"{customer_ref.first_name or ''} {customer_ref.last_name or ''}".strip() or 'Walk-in',
                'mobile': getattr(customer_ref, 'mobile', None),
                'id': str(customer_ref.id) if hasattr(customer_ref, 'id') else None
            }
    except Exception:
        pass
    
    return {'name': 'Walk-in', 'mobile': None, 'id': None}

@report_bp.before_request
def handle_preflight():
    """Handle CORS preflight requests"""
    if request.method == "OPTIONS":
        response = jsonify({})
        response.headers.add("Access-Control-Allow-Origin", "*")
        response.headers.add('Access-Control-Allow-Headers', "*")
        response.headers.add('Access-Control-Allow-Methods', "*")
        return response

@report_bp.route('/service-sales-analysis', methods=['GET'])
@require_role('manager', 'owner')
def service_sales_analysis(current_user=None):
    """Service performance analysis report (Manager and Owner only)"""
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        service_group = request.args.get('service_group')  # Add service group filter parameter

        # Get branch for filtering
        branch = get_selected_branch(request, current_user)
        bills_query = Bill.objects(is_deleted=False)
        if branch:
            bills_query = bills_query.filter(branch=branch)

        if start_date or end_date:
            start, end = get_ist_date_range(start_date, end_date)
            if start:
                bills_query = bills_query.filter(bill_date__gte=start)
            if end:
                bills_query = bills_query.filter(bill_date__lte=end)

        # Force evaluation by converting to list
        bills = list(bills_query)

        # Group by service
        service_stats = {}
        for bill in bills:
            for item in bill.items:
                if item.item_type == 'service' and item.service:
                    try:
                        # Reload service to ensure it's dereferenced
                        item.service.reload()
                        service_id = str(item.service.id)
                        
                        # Get service group name
                        service_group_name = None
                        if hasattr(item.service, 'group') and item.service.group:
                            try:
                                item.service.group.reload()
                                service_group_name = item.service.group.name if hasattr(item.service.group, 'name') else None
                            except (DoesNotExist, AttributeError):
                                pass
                        
                        # Filter by service group if specified
                        if service_group and service_group != 'all':
                            if not service_group_name or service_group_name.lower() != service_group.lower():
                                continue
                        
                        if service_id not in service_stats:
                            service_stats[service_id] = {
                                'service_name': item.service.name if hasattr(item.service, 'name') else 'Unknown Service',
                                'service_group': service_group_name,
                                'count': 0,
                                'revenue': 0
                            }
                        
                        service_stats[service_id]['count'] += int(item.quantity) if item.quantity else 0
                        service_stats[service_id]['revenue'] += float(item.total) if item.total else 0.0
                    except (DoesNotExist, AttributeError, TypeError) as e:
                        # Skip items with broken references
                        continue

        # Convert to list and sort by revenue
        results = sorted(service_stats.values(), key=lambda x: x['revenue'], reverse=True)

        response = jsonify(results)
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response
    except Exception as e:
        response = jsonify({'error': str(e)})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 500

@report_bp.route('/list-of-bills', methods=['GET'])
@require_role('manager', 'owner')
def list_of_bills(current_user=None):
    """Bills list report with date range (Manager and Owner only)"""
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        customer_id = request.args.get('customer_id', type=str)

        # Get branch for filtering
        branch = get_selected_branch(request, current_user)
        query = Bill.objects(is_deleted=False)
        if branch:
            query = query.filter(branch=branch)

        if start_date or end_date:
            start, end = get_ist_date_range(start_date, end_date)
            if start:
                query = query.filter(bill_date__gte=start)
            if end:
                query = query.filter(bill_date__lte=end)
        if customer_id and ObjectId.is_valid(customer_id):
            query = query.filter(customer=ObjectId(customer_id))

        # Only load the fields this endpoint actually needs, and skip auto-
        # dereferencing the customer ref. We batch-fetch customers below in one
        # query, avoiding the N+1 round-trips to Atlas that made this endpoint
        # take up to 2 minutes.
        bills = list(
            query.order_by('-bill_date')
                 .no_dereference()
                 .only(
                     'bill_number', 'bill_date', 'customer',
                     'subtotal', 'discount_amount', 'tax_amount',
                     'final_amount', 'payment_mode', 'booking_status'
                 )
        )

        customer_ids = set()
        for b in bills:
            cref = b._data.get('customer')
            if cref is None:
                continue
            cid = getattr(cref, 'id', cref)
            if cid is not None:
                customer_ids.add(cid)

        customer_map = {}
        if customer_ids:
            for c in Customer.objects(id__in=list(customer_ids)).only(
                'first_name', 'last_name', 'mobile'
            ):
                customer_map[c.id] = c

        result = []
        for b in bills:
            try:
                bill_date_iso = b.bill_date.isoformat() if b.bill_date else None

                cref = b._data.get('customer')
                cid = getattr(cref, 'id', cref) if cref is not None else None
                customer = customer_map.get(cid)
                if customer is not None:
                    name = f"{customer.first_name or ''} {customer.last_name or ''}".strip() or 'Walk-in'
                    mobile = customer.mobile
                    cust_id_str = str(customer.id)
                else:
                    name = 'Walk-in'
                    mobile = None
                    cust_id_str = None

                result.append({
                    'bill_number': b.bill_number,
                    'bill_date': bill_date_iso,
                    'customer_name': name,
                    'customer_mobile': mobile,
                    'customer_id': cust_id_str,
                    'id': str(b.id),
                    'subtotal': b.subtotal,
                    'discount': b.discount_amount,
                    'tax': b.tax_amount,
                    'final_amount': b.final_amount,
                    'payment_mode': b.payment_mode,
                    'booking_status': b.booking_status
                })
            except Exception as e:
                print(f"Error processing bill {b.id}: {e}")
                continue

        response = jsonify(result)
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response
    except Exception as e:
        response = jsonify({'error': str(e)})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 500

@report_bp.route('/deleted-bills', methods=['GET'])
@require_role('manager', 'owner')
def deleted_bills_report(current_user=None):
    """Deleted bills report with reasons (Manager and Owner only)"""
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')

        # Get branch for filtering
        branch = get_selected_branch(request, current_user)
        query = Bill.objects(is_deleted=True)
        if branch:
            query = query.filter(branch=branch)

        if start_date:
            start = datetime.strptime(start_date, '%Y-%m-%d')
            query = query.filter(deleted_at__gte=start)
        if end_date:
            # Set end_date to end of day to include all bills on that date
            end = datetime.strptime(end_date, '%Y-%m-%d')
            end = end.replace(hour=23, minute=59, second=59, microsecond=999999)
            query = query.filter(deleted_at__lte=end)

        # Force evaluation by converting to list
        bills = list(query.order_by('-deleted_at'))

        result = []
        for b in bills:
            try:
                customer_info = get_safe_customer_info(b.customer)
                result.append({
                    'bill_number': b.bill_number,
                    'bill_date': b.bill_date.isoformat() if b.bill_date else None,
                    'deleted_at': b.deleted_at.isoformat() if b.deleted_at else None,
                    'customer_name': customer_info['name'],
                    'final_amount': b.final_amount,
                    'deletion_reason': b.deletion_reason
                })
            except Exception as e:
                print(f"Error processing deleted bill {b.id}: {e}")
                continue
        
        response = jsonify(result)
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response
    except Exception as e:
        response = jsonify({'error': str(e)})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 500

@report_bp.route('/sales-by-service-group', methods=['GET'])
@require_role('manager', 'owner')
def sales_by_service_group(current_user=None):
    """Sales grouped by service group (Manager and Owner only)"""
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')

        # Get branch for filtering
        branch = get_selected_branch(request, current_user)
        bills_query = Bill.objects(is_deleted=False)
        if branch:
            bills_query = bills_query.filter(branch=branch)

        if start_date or end_date:
            start, end = get_ist_date_range(start_date, end_date)
            if start:
                bills_query = bills_query.filter(bill_date__gte=start)
            if end:
                bills_query = bills_query.filter(bill_date__lte=end)

        # Force evaluation by converting to list
        bills = list(bills_query)

        # Group by service group
        group_stats = {}
        for bill in bills:
            for item in bill.items:
                if item.item_type == 'service' and item.service and item.service.group:
                    group_name = item.service.group.name
                    if group_name not in group_stats:
                        group_stats[group_name] = {
                            'count': 0,
                            'revenue': 0.0
                        }
                    group_stats[group_name]['count'] += int(item.quantity) if item.quantity else 0
                    group_stats[group_name]['revenue'] += float(item.total) if item.total else 0.0

        total_revenue = sum([stats['revenue'] for stats in group_stats.values()])

        results = [{
            'group_name': name,
            'count': stats['count'],
            'revenue': round(stats['revenue'], 2),
            'percentage': round((stats['revenue'] / total_revenue * 100) if total_revenue > 0 else 0, 2)
        } for name, stats in group_stats.items()]
        
        # Sort by revenue
        results.sort(key=lambda x: x['revenue'], reverse=True)

        response = jsonify(results)
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response
    except Exception as e:
        response = jsonify({'error': str(e)})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 500

@report_bp.route('/membership-clients', methods=['GET'])
@require_role('manager', 'owner')
def membership_clients_report(current_user=None):
    """Active membership clients (Manager and Owner only)"""
    try:
        status = request.args.get('status', 'active')

        # Get branch for filtering
        branch = get_selected_branch(request, current_user)
        memberships_query = Membership.objects(status=status)
        if branch:
            memberships_query = memberships_query.filter(branch=branch)
        # Force evaluation by converting to list
        memberships = list(memberships_query.order_by('-purchase_date'))

        response = jsonify([{
            'customer_name': f"{m.customer.first_name} {m.customer.last_name}" if m.customer else None,
            'customer_mobile': m.customer.mobile if m.customer else None,
            'membership_name': m.name,
            'price': m.price,
            'purchase_date': m.purchase_date.isoformat() if m.purchase_date else None,
            'expiry_date': m.expiry_date.isoformat() if m.expiry_date else None,
            'days_remaining': (m.expiry_date - datetime.now()).days if m.expiry_date and m.expiry_date > datetime.now() else 0,
            'plan': {
                'allocated_discount': m.plan.allocated_discount if m.plan else 0
            } if m.plan else None
        } for m in memberships])
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response
    except Exception as e:
        response = jsonify({'error': str(e)})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 500

@report_bp.route('/staff-incentive', methods=['GET'])
@require_role('manager', 'owner')
def staff_incentive_report(current_user=None):
    """Staff commission/incentive report with breakdown by item type (Manager and Owner only)"""
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')

        # Get branch for filtering
        branch = get_selected_branch(request, current_user)
        staff_query = Staff.objects(status='active')
        if branch:
            staff_query = staff_query.filter(branch=branch)
        # Force evaluation by converting to list
        staff_list = list(staff_query)

        report = []
        for staff in staff_list:
            bills_query = Bill.objects(is_deleted=False)
            if branch:
                bills_query = bills_query.filter(branch=branch)

            if start_date:
                start = datetime.strptime(start_date, '%Y-%m-%d')
                bills_query = bills_query.filter(bill_date__gte=start)
            if end_date:
                end = datetime.strptime(end_date, '%Y-%m-%d')
                # Set end to end of day to include all data from the end date
                end = end.replace(hour=23, minute=59, second=59, microsecond=999999)
                bills_query = bills_query.filter(bill_date__lte=end)

            # Force evaluation by converting to list
            bills = list(bills_query)

            # Breakdown by item type
            service_revenue = 0.0
            package_revenue = 0.0
            product_revenue = 0.0
            membership_revenue = 0.0
            total_revenue = 0.0
            item_count = 0

            for bill in bills:
                for item in bill.items:
                    if item.staff and str(item.staff.id) == str(staff.id):
                        item_total = float(item.total) if item.total else 0.0
                        total_revenue += item_total
                        item_count += 1
                        
                        if item.item_type == 'service':
                            service_revenue += item_total
                        elif item.item_type == 'package':
                            package_revenue += item_total
                        elif item.item_type == 'product':
                            product_revenue += item_total
                        elif item.item_type == 'membership':
                            membership_revenue += item_total
            
            avg_bill = total_revenue / item_count if item_count > 0 else 0
            commission = total_revenue * (staff.commission_rate / 100) if staff.commission_rate else 0

            report.append({
                'staff_name': f"{staff.first_name} {staff.last_name}",
                'item_count': item_count,
                'service': round(service_revenue, 2),
                'package': round(package_revenue, 2),
                'product': round(product_revenue, 2),
                'membership': round(membership_revenue, 2),
                'total': round(total_revenue, 2),
                'avg_bill': round(avg_bill, 2),
                'total_revenue': round(total_revenue, 2),
                'commission_rate': staff.commission_rate,
                'commission_earned': round(commission, 2),
                'salary': staff.salary,
                'total_earnings': round((staff.salary or 0) + commission, 2)
            })

        # Sort by total revenue
        report.sort(key=lambda x: x['total_revenue'], reverse=True)

        response = jsonify(report)
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response
    except Exception as e:
        response = jsonify({'error': str(e)})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 500

@report_bp.route('/expense-report', methods=['GET'])
@require_role('manager', 'owner')
def expense_report(current_user=None):
    """Expense report with filters"""
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        category_id = request.args.get('category_id', type=str)
        payment_mode = request.args.get('payment_mode')

        # Get branch for filtering
        branch = get_selected_branch(request, current_user)
        query = Expense.objects
        if branch:
            query = query.filter(branch=branch)

        if start_date:
            start = datetime.strptime(start_date, '%Y-%m-%d').date()
            query = query.filter(expense_date__gte=start)
        if end_date:
            end = datetime.strptime(end_date, '%Y-%m-%d').date()
            query = query.filter(expense_date__lte=end)
        if category_id and ObjectId.is_valid(category_id):
            try:
                from models import ExpenseCategory
                category = ExpenseCategory.objects.get(id=category_id)
                query = query.filter(category=category)
            except DoesNotExist:
                pass
        if payment_mode:
            query = query.filter(payment_mode=payment_mode)

        # Force evaluation by converting to list
        expenses = list(query.order_by('-expense_date'))

        total = sum([float(e.amount) for e in expenses])

        response = jsonify({
            'expenses': [{
                'date': e.expense_date.isoformat() if e.expense_date else None,
                'category': e.category.name if e.category else None,
                'name': e.name,
                'amount': e.amount,
                'payment_mode': e.payment_mode,
                'description': e.description
            } for e in expenses],
            'total_expenses': round(total, 2),
            'count': len(list(expenses))
        })
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response
    except Exception as e:
        response = jsonify({'error': str(e)})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 500

@report_bp.route('/inventory-report', methods=['GET'])
def inventory_report():
    """Stock levels and low stock items"""
    try:
        category_id = request.args.get('category_id', type=str)
        low_stock_only = request.args.get('low_stock_only', type=bool, default=False)

        query = Product.objects(status='active')

        if category_id and ObjectId.is_valid(category_id):
            try:
                from models import ProductCategory
                category = ProductCategory.objects.get(id=category_id)
                query = query.filter(category=category)
            except DoesNotExist:
                pass

        products = list(query.order_by('stock_quantity'))
        
        # Filter low stock in Python (MongoEngine doesn't support field comparison)
        if low_stock_only:
            products = [p for p in products if p.stock_quantity and p.min_stock_level and p.stock_quantity <= p.min_stock_level]

        total_stock_value = sum([(p.stock_quantity or 0) * (p.cost or 0) for p in products])
        low_stock_count = len([p for p in products if p.stock_quantity and p.min_stock_level and p.stock_quantity <= p.min_stock_level])

        response = jsonify({
            'products': [{
                'name': p.name,
                'category': p.category.name if p.category else None,
                'stock_quantity': p.stock_quantity,
                'min_stock_level': p.min_stock_level,
                'cost': p.cost,
                'price': p.price,
                'stock_value': (p.stock_quantity or 0) * (p.cost or 0),
                'status': 'Low Stock' if (p.stock_quantity and p.min_stock_level and p.stock_quantity <= p.min_stock_level) else 'In Stock'
            } for p in products],
            'summary': {
                'total_products': len(products),
                'low_stock_items': low_stock_count,
                'total_stock_value': round(total_stock_value, 2)
            }
        })
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response
    except Exception as e:
        response = jsonify({'error': str(e)})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 500

@report_bp.route('/staff-combined', methods=['GET'])
def staff_combined_report():
    """Combined staff performance and bill report"""
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        staff_id = request.args.get('staff_id')

        query = Bill.objects.filter(is_deleted=False)

        if start_date:
            start = datetime.strptime(start_date, '%Y-%m-%d')
            query = query.filter(bill_date__gte=start)
        if end_date:
            end = datetime.strptime(end_date, '%Y-%m-%d')
            # Set end to end of day to include all data from the end date
            end = end.replace(hour=23, minute=59, second=59, microsecond=999999)
            query = query.filter(bill_date__lte=end)

        # Force evaluation by converting to list
        bills = list(query)

        # Group by staff
        staff_data = {}
        for bill in bills:
            for item in (bill.items or []):
                if not item.staff:
                    continue
                
                item_staff_id = str(item.staff.id)
                
                # Filter by staff_id if provided
                if staff_id and item_staff_id != staff_id:
                    continue
                
                if item_staff_id not in staff_data:
                    staff_data[item_staff_id] = {
                        'staff_name': f"{item.staff.first_name} {item.staff.last_name}" if hasattr(item.staff, 'first_name') else 'Unknown',
                        'services_count': 0,
                        'revenue': 0,
                        'services': []
                    }

                staff_data[item_staff_id]['services_count'] += 1
                staff_data[item_staff_id]['revenue'] += item.total or 0

                if item.service:
                    staff_data[item_staff_id]['services'].append({
                        'service_name': item.service.name if hasattr(item.service, 'name') else 'Unknown',
                        'bill_number': bill.bill_number,
                        'date': bill.bill_date.isoformat() if isinstance(bill.bill_date, datetime) else str(bill.bill_date),
                        'amount': item.total or 0
                    })

        results = sorted(staff_data.values(), key=lambda x: x['revenue'], reverse=True)

        response = jsonify(results)
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response
    except Exception as e:
        response = jsonify({'error': str(e)})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 500

@report_bp.route('/business-growth', methods=['GET'])
def business_growth_report():
    """Business growth and trend analysis"""
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')

        if not start_date:
            start_date = (datetime.now().replace(day=1) - timedelta(days=90)).strftime('%Y-%m-%d')
        if not end_date:
            end_date = datetime.now().strftime('%Y-%m-%d')

        start = datetime.strptime(start_date, '%Y-%m-%d')
        end = datetime.strptime(end_date, '%Y-%m-%d')
        # Set end to end of day to include all data from the end date
        end = end.replace(hour=23, minute=59, second=59, microsecond=999999)

        # Get all bills in date range - force evaluation
        bills = list(Bill.objects.filter(
            is_deleted=False,
            bill_date__gte=start,
            bill_date__lte=end
        ))

        # Group bills by month
        monthly_revenue = {}
        for bill in bills:
            month_key = bill.bill_date.strftime('%Y-%m')
            if month_key not in monthly_revenue:
                monthly_revenue[month_key] = {'revenue': 0, 'bills': 0}
            monthly_revenue[month_key]['revenue'] += bill.final_amount or 0
            monthly_revenue[month_key]['bills'] += 1

        # Get all expenses in date range - force evaluation
        expenses = list(Expense.objects.filter(
            expense_date__gte=start.date(),
            expense_date__lte=end.date()
        ))

        # Group expenses by month
        monthly_expenses = {}
        for expense in expenses:
            if expense.expense_date:
                month_key = expense.expense_date.strftime('%Y-%m')
                if month_key not in monthly_expenses:
                    monthly_expenses[month_key] = 0
                monthly_expenses[month_key] += expense.amount or 0

        # Combine data
        growth_data = []
        for month in sorted(monthly_revenue.keys()):
            revenue_data = monthly_revenue[month]
            expenses = monthly_expenses.get(month, 0)
            profit = revenue_data['revenue'] - expenses

            growth_data.append({
                'month': month,
                'revenue': round(revenue_data['revenue'], 2),
                'expenses': round(expenses, 2),
                'profit': round(profit, 2),
                'bills': revenue_data['bills']
            })

        response = jsonify(growth_data)
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response
    except Exception as e:
        response = jsonify({'error': str(e)})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 500

@report_bp.route('/staff-performance', methods=['GET'])
@require_role('manager', 'owner')
def staff_performance_analysis(current_user=None):
    """Staff performance analysis - OPTIMIZED with aggregation"""
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')

        # Use proper IST-to-UTC date conversion
        if start_date and end_date:
            start, end = get_ist_date_range(start_date, end_date)
        elif start_date:
            start, end = get_ist_date_range(start_date, datetime.now().strftime('%Y-%m-%d'))
        else:
            default_start = (datetime.now() - timedelta(days=90)).strftime('%Y-%m-%d')
            default_end = datetime.now().strftime('%Y-%m-%d')
            start, end = get_ist_date_range(default_start, default_end)
        
        # OPTIMIZED: Use aggregation pipeline instead of loading all bills
        # Company-wide: No branch filtering - show all staff performance
        match_stage = {
            "is_deleted": False,
            "bill_date": {"$gte": start, "$lte": end},
            "items.staff": {"$ne": None}
        }

        # Build staff match condition (only filter by active status, not branch)
        staff_match_condition = {"staff_doc.status": "active"}

        # Aggregation pipeline for staff performance
        pipeline = [
            {"$match": match_stage},
            {"$unwind": "$items"},
            {"$match": {"items.staff": {"$ne": None}}},
            {"$group": {
                "_id": "$items.staff",
                "total_revenue": {"$sum": {"$ifNull": ["$items.total", 0]}},
                "item_count": {"$sum": {"$ifNull": ["$items.quantity", 1]}},
                "service_revenue": {
                    "$sum": {
                        "$cond": [
                            {"$eq": ["$items.item_type", "service"]},
                            {"$ifNull": ["$items.total", 0]},
                            0
                        ]
                    }
                },
                "package_revenue": {
                    "$sum": {
                        "$cond": [
                            {"$eq": ["$items.item_type", "package"]},
                            {"$ifNull": ["$items.total", 0]},
                            0
                        ]
                    }
                },
                "product_revenue": {
                    "$sum": {
                        "$cond": [
                            {"$eq": ["$items.item_type", "product"]},
                            {"$ifNull": ["$items.total", 0]},
                            0
                        ]
                    }
                },
                "membership_revenue": {
                    "$sum": {
                        "$cond": [
                            {"$eq": ["$items.item_type", "membership"]},
                            {"$ifNull": ["$items.total", 0]},
                            0
                        ]
                    }
                },
                "service_items": {
                    "$push": {
                        "$cond": [
                            {"$eq": ["$items.item_type", "service"]},
                            {
                                "service_id": "$items.service",
                                "quantity": {"$ifNull": ["$items.quantity", 1]},
                                "revenue": {"$ifNull": ["$items.total", 0]}
                            },
                            "$$REMOVE"
                        ]
                    }
                }
            }},
            {"$lookup": {
                "from": "staffs",
                "localField": "_id",
                "foreignField": "_id",
                "as": "staff_doc"
            }},
            {"$unwind": {"path": "$staff_doc", "preserveNullAndEmptyArrays": True}},
            {"$match": staff_match_condition},
            {"$project": {
                "staff_id": {"$toString": "$_id"},
                "staff_name": {
                    "$trim": {
                        "input": {
                            "$concat": [
                                {"$ifNull": ["$staff_doc.first_name", ""]},
                                " ",
                                {"$ifNull": ["$staff_doc.last_name", ""]}
                            ]
                        }
                    }
                },
                "total_revenue": {"$round": ["$total_revenue", 2]},
                "item_count": 1,
                "service_revenue": {"$round": ["$service_revenue", 2]},
                "package_revenue": {"$round": ["$package_revenue", 2]},
                "product_revenue": {"$round": ["$product_revenue", 2]},
                "membership_revenue": {"$round": ["$membership_revenue", 2]},
                "service_items": 1
            }}
        ]

        # Execute aggregation
        staff_performance_results = list(Bill.objects.aggregate(pipeline))

        # Get service IDs for service breakdown lookup
        service_ids = set()
        for result in staff_performance_results:
            for item in result.get('service_items', []):
                if item and item.get('service_id'):
                    service_ids.add(item['service_id'])

        # Batch lookup services and their groups
        service_group_map = {}
        if service_ids:
            services_pipeline = [
                {"$match": {"_id": {"$in": list(service_ids)}}},
                {"$lookup": {
                    "from": "service_groups",
                    "localField": "group",
                    "foreignField": "_id",
                    "as": "group_doc"
                }},
                {"$unwind": {"path": "$group_doc", "preserveNullAndEmptyArrays": True}},
                {"$project": {
                    "service_id": {"$toString": "$_id"},
                    "group_name": {"$ifNull": ["$group_doc.name", "Other"]}
                }}
            ]
            from models import Service
            service_groups = list(Service.objects.aggregate(services_pipeline))
            service_group_map = {s['service_id']: s['group_name'] for s in service_groups}

        # Build performance list with service breakdown
        performance = []
        staff_names_with_revenue = set()
        for result in staff_performance_results:
            # Calculate service breakdown by group
            service_breakdown = {}
            for item in result.get('service_items', []):
                if not item or not item.get('service_id'):
                    continue

                service_id = str(item['service_id'])
                group_name = service_group_map.get(service_id, 'Other')

                if group_name not in service_breakdown:
                    service_breakdown[group_name] = {'count': 0, 'revenue': 0.0}

                service_breakdown[group_name]['count'] += item.get('quantity', 1)
                service_breakdown[group_name]['revenue'] += item.get('revenue', 0.0)

            # Round service breakdown values
            for group_name in service_breakdown:
                service_breakdown[group_name]['revenue'] = round(service_breakdown[group_name]['revenue'], 2)

            total_revenue = result.get('total_revenue', 0.0)
            item_count = result.get('item_count', 0)
            staff_name = result.get('staff_name', '').strip()
            staff_names_with_revenue.add(result.get('staff_id', ''))

            performance.append({
                'staff_name': staff_name,
                'total_revenue': total_revenue,
                'total_services': int(item_count),
                'service_revenue': result.get('service_revenue', 0.0),
                'package_revenue': result.get('package_revenue', 0.0),
                'product_revenue': result.get('product_revenue', 0.0),
                'membership_revenue': result.get('membership_revenue', 0.0),
                'service_breakdown': service_breakdown,
                'average_per_service': round(total_revenue / item_count, 2) if item_count > 0 else 0
            })

        # Include all active staff in the selected branch (even those with zero revenue in this period)
        from models import Staff as StaffModel
        all_active_staff_query = StaffModel.objects(status='active')
        if branch:
            all_active_staff_query = all_active_staff_query.filter(branch=branch)
        all_active_staff = list(all_active_staff_query)
        
        for staff in all_active_staff:
            if str(staff.id) not in staff_names_with_revenue:
                name = f"{staff.first_name or ''} {staff.last_name or ''}".strip()
                performance.append({
                    'staff_name': name,
                    'total_revenue': 0.0,
                    'total_services': 0,
                    'service_revenue': 0.0,
                    'package_revenue': 0.0,
                    'product_revenue': 0.0,
                    'membership_revenue': 0.0,
                    'service_breakdown': {},
                    'average_per_service': 0
                })

        # Sort by total revenue
        performance.sort(key=lambda x: x['total_revenue'], reverse=True)

        response = jsonify(performance)
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response
    except Exception as e:
        import traceback
        error_trace = traceback.format_exc()
        print(f"Error in staff_performance_analysis: {str(e)}")
        print(f"Traceback: {error_trace}")
        response = jsonify({'error': str(e), 'traceback': error_trace})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 500

@report_bp.route('/period-summary', methods=['GET'])
def period_summary():
    """Period performance summary"""
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')

        if not start_date or not end_date:
            response = jsonify({'error': 'start_date and end_date are required'})
            response.headers.add('Access-Control-Allow-Origin', '*')
            return response, 400

        start = datetime.strptime(start_date, '%Y-%m-%d')
        end = datetime.strptime(end_date, '%Y-%m-%d')
        # Set end to end of day to include all data from the end date
        end = end.replace(hour=23, minute=59, second=59, microsecond=999999)

        # Revenue - force evaluation
        bills = list(Bill.objects.filter(
            is_deleted=False,
            bill_date__gte=start,
            bill_date__lte=end
        ))
        total_revenue = sum(bill.final_amount or 0 for bill in bills)
        total_bills = len(bills)

        # Expenses - force evaluation
        expenses = list(Expense.objects.filter(
            expense_date__gte=start.date(),
            expense_date__lte=end.date()
        ))
        total_expenses = sum(expense.amount or 0 for expense in expenses)

        # Profit
        profit = total_revenue - total_expenses

        # Customers served
        customer_ids = set()
        for bill in bills:
            if bill.customer:
                customer_ids.add(str(bill.customer.id))
        customers_served = len(customer_ids)

        # Appointments
        appointments = Appointment.objects.filter(
            appointment_date__gte=start.date(),
            appointment_date__lte=end.date()
        ).count()

        response = jsonify({
            'period': {
                'start_date': start_date,
                'end_date': end_date
            },
            'revenue': {
                'total': round(total_revenue, 2),
                'average_per_bill': round(total_revenue / total_bills, 2) if total_bills > 0 else 0
            },
            'bills': {
                'total': total_bills
            },
            'expenses': {
                'total': round(total_expenses, 2)
            },
            'profit': {
                'total': round(profit, 2),
                'margin': round((profit / total_revenue * 100) if total_revenue > 0 else 0, 2)
            },
            'customers': {
                'served': customers_served
            },
            'appointments': {
                'total': appointments
            }
        })
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response
    except Exception as e:
        response = jsonify({'error': str(e)})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 500
