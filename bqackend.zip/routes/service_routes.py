from flask import Blueprint, request, jsonify
from models import Service, ServiceGroup, to_dict
from datetime import datetime
from mongoengine.errors import DoesNotExist, ValidationError
from bson import ObjectId
from utils.auth import require_auth, require_role
from utils.branch_filter import get_selected_branch
from utils.redis_cache import cache_response

service_bp = Blueprint('services', __name__)

def verify_branch_access(item, branch, item_type='item'):
    """Verify that an item belongs to the specified branch"""
    if not branch:
        return False, 'Branch is required'
    if not item:
        return False, f'{item_type} not found'
    if not item.branch:
        return False, f'{item_type} has no branch assigned (legacy data)'
    if str(item.branch.id) != str(branch.id):
        return False, f'{item_type} belongs to a different branch'
    return True, None

@service_bp.before_request
def handle_preflight():
    """Handle CORS preflight requests"""
    if request.method == "OPTIONS":
        response = jsonify({})
        response.headers.add("Access-Control-Allow-Origin", "*")
        response.headers.add('Access-Control-Allow-Headers', "*")
        response.headers.add('Access-Control-Allow-Methods', "*")
        return response

# Service Group Routes
@service_bp.route('/groups', methods=['GET'])
@require_auth
def get_service_groups(current_user=None):
    """Get all service groups with counts filtered by branch"""
    # Get branch for filtering
    branch = get_selected_branch(request, current_user)
    
    # Force evaluation by converting to list
    groups = list(ServiceGroup.objects.order_by('display_order'))
    
    # Calculate counts per group, filtered by branch if branch is set
    groups_with_counts = []
    for g in groups:
        query = Service.objects(group=g, status='active')
        if branch:
            query = query.filter(branch=branch)
        count = query.count()
        groups_with_counts.append({
            'id': str(g.id),
            'name': g.name,
            'count': count,
            'displayOrder': g.display_order
        })
    
    response = jsonify({
        'groups': groups_with_counts
    })
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

@service_bp.route('/groups', methods=['POST'])
@require_role('manager', 'owner')
def create_service_group(current_user=None):
    """Create new service group (Manager and Owner only)"""
    data = request.json
    
    group = ServiceGroup(
        name=data.get('name', ''),
        display_order=data.get('displayOrder', 0)
    )
    group.save()
    
    response = jsonify({'id': str(group.id), 'message': 'Service group created successfully'})
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response, 201

@service_bp.route('/groups/<group_id>', methods=['PUT'])
@require_role('manager', 'owner')
def update_service_group(group_id, current_user=None):
    """Update service group (Manager and Owner only)"""
    try:
        if not ObjectId.is_valid(group_id):
            return jsonify({'error': 'Invalid group ID format'}), 400
        group = ServiceGroup.objects.get(id=group_id)
    except DoesNotExist:
        return jsonify({'error': 'Service group not found'}), 404
    
    data = request.json
    
    group.name = data.get('name', group.name)
    group.display_order = data.get('displayOrder', group.display_order)
    group.save()
    
    response = jsonify({'message': 'Service group updated successfully'})
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

@service_bp.route('/groups/<group_id>', methods=['DELETE'])
@require_role('manager', 'owner')
def delete_service_group(group_id, current_user=None):
    """Delete service group (Manager and Owner only)"""
    try:
        if not ObjectId.is_valid(group_id):
            return jsonify({'error': 'Invalid group ID format'}), 400
        group = ServiceGroup.objects.get(id=group_id)
    except DoesNotExist:
        return jsonify({'error': 'Service group not found'}), 404
    
    group.delete()
    response = jsonify({'message': 'Service group deleted successfully'})
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

# Service Routes
@service_bp.route('/', methods=['GET'])
@require_auth
@cache_response(ttl=300)  # Cache for 5 minutes
def get_services(current_user=None):
    """Get all services, optionally filtered by group and branch

    OPTIMIZED: Added caching, removed debug prints, efficient querying
    """
    group_id = request.args.get('group_id', type=str)
    search = request.args.get('search', '')

    # Filter by branch - strict filtering, only show services belonging to selected branch
    branch = get_selected_branch(request, current_user)

    # Build query with all filters upfront
    query = Service.objects(status='active')
    if branch:
        query = query.filter(branch=branch)

    if group_id and ObjectId.is_valid(group_id):
        try:
            group = ServiceGroup.objects.get(id=group_id)
            query = query.filter(group=group)
        except (DoesNotExist, ValidationError):
            pass

    if search:
        query = query.filter(name__icontains=search)

    # Get pagination parameters - allow up to 1000 for Quick Sale
    page = request.args.get('page', 1, type=int)
    per_page = min(request.args.get('per_page', 20, type=int), 1000)
    sort_by = request.args.get('sort_by', 'name')
    sort_order = request.args.get('sort_order', 'asc')

    # Apply sorting
    order_field = f"-{sort_by}" if sort_order == 'desc' else sort_by
    query = query.order_by(order_field)

    # Use only() to limit fields and avoid loading unnecessary data
    query = query.only('id', 'name', 'group', 'price', 'duration', 'description', 'branch')

    # Get total count (single count query)
    total = query.count()

    # Apply pagination and fetch
    services = list(query.skip((page - 1) * per_page).limit(per_page))

    # Pre-fetch all service groups to avoid N+1 queries
    group_ids = set()
    for s in services:
        raw_group = s._data.get('group')
        if raw_group:
            gid = raw_group if isinstance(raw_group, ObjectId) else getattr(raw_group, 'id', raw_group)
            group_ids.add(gid)

    group_map = {}
    if group_ids:
        for g in ServiceGroup.objects(id__in=list(group_ids)).only('id', 'name'):
            group_map[str(g.id)] = g.name

    # Build response using pre-fetched group map
    service_data = []
    for s in services:
        try:
            raw_group = s._data.get('group')
            group_id_str = str(raw_group) if raw_group else None
            raw_branch = s._data.get('branch')
            branch_id_str = str(raw_branch) if raw_branch else None

            service_data.append({
                'id': str(s.id),
                'name': s.name,
                'groupId': group_id_str,
                'groupName': group_map.get(group_id_str) if group_id_str else None,
                'price': s.price,
                'duration': s.duration,
                'description': s.description,
                'branchId': branch_id_str
            })
        except Exception:
            # Skip services with broken references
            continue

    response = jsonify({
        'data': service_data,
        'pagination': {
            'total': total,
            'page': page,
            'per_page': per_page,
            'pages': (total + per_page - 1) // per_page if per_page > 0 else 0
        }
    })
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

@service_bp.route('/<service_id>', methods=['GET'])
def get_service(service_id):
    """Get single service"""
    try:
        if not ObjectId.is_valid(service_id):
            return jsonify({'error': 'Invalid service ID format'}), 400
        service = Service.objects.get(id=service_id)
    except DoesNotExist:
        return jsonify({'error': 'Service not found'}), 404
    except ValidationError:
        return jsonify({'error': 'Invalid service ID format'}), 400
    
    response = jsonify({
        'id': str(service.id),
        'name': service.name,
        'groupId': str(service.group.id) if service.group else None,
        'price': service.price,
        'duration': service.duration,
        'description': service.description
    })
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

@service_bp.route('/', methods=['POST'])
@require_role('staff', 'manager', 'owner')
def create_service(current_user=None):
    """Create new service (Staff, Manager and Owner)"""
    data = request.json

    # Get branch for the service
    branch = get_selected_branch(request, current_user)
    if not branch:
        return jsonify({'error': 'Branch is required to create a service'}), 400

    # Get group reference
    group = None
    if data.get('groupId'):
        if not ObjectId.is_valid(data.get('groupId')):
            return jsonify({'error': 'Invalid group ID format'}), 400
        try:
            group = ServiceGroup.objects.get(id=data.get('groupId'))
        except DoesNotExist:
            return jsonify({'error': 'Service group not found'}), 400
        except ValidationError:
            return jsonify({'error': 'Invalid group ID format'}), 400

    service = Service(
        name=data.get('name', ''),
        group=group,
        price=data.get('price', 0.0),
        duration=data.get('duration'),
        description=data.get('description', ''),
        branch=branch,
        status=data.get('status', 'active')
    )
    service.save()

    response = jsonify({'id': str(service.id), 'message': 'Service created successfully'})
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response, 201

@service_bp.route('/<service_id>', methods=['PUT'])
@require_role('staff', 'manager', 'owner')
def update_service(service_id, current_user=None):
    """Update service (Staff, Manager and Owner)"""
    try:
        if not ObjectId.is_valid(service_id):
            return jsonify({'error': 'Invalid service ID format'}), 400
        service = Service.objects.get(id=service_id)
    except DoesNotExist:
        return jsonify({'error': 'Service not found'}), 404
    
    # Verify branch access
    branch = get_selected_branch(request, current_user)
    if not branch:
        response = jsonify({'error': 'Branch is required'})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 400
    
    is_valid, error_msg = verify_branch_access(service, branch, 'Service')
    if not is_valid:
        response = jsonify({'error': error_msg})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 403
    
    data = request.json
    
    service.name = data.get('name', service.name)
    if 'groupId' in data:
        if data['groupId']:
            if not ObjectId.is_valid(data['groupId']):
                return jsonify({'error': 'Invalid group ID format'}), 400
            try:
                service.group = ServiceGroup.objects.get(id=data['groupId'])
            except DoesNotExist:
                return jsonify({'error': 'Service group not found'}), 400
            except ValidationError:
                return jsonify({'error': 'Invalid group ID format'}), 400
        else:
            service.group = None
    service.price = data.get('price', service.price)
    service.duration = data.get('duration', service.duration)
    service.description = data.get('description', service.description)
    service.status = data.get('status', service.status)
    service.updated_at = datetime.utcnow()
    service.save()
    
    response = jsonify({'message': 'Service updated successfully'})
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

@service_bp.route('/<service_id>', methods=['DELETE'])
@require_role('manager', 'owner')
def delete_service(service_id, current_user=None):
    """Delete service (Manager and Owner only - soft delete)"""
    try:
        if not ObjectId.is_valid(service_id):
            return jsonify({'error': 'Invalid service ID format'}), 400
        service = Service.objects.get(id=service_id)
    except DoesNotExist:
        return jsonify({'error': 'Service not found'}), 404
    
    # Verify branch access
    branch = get_selected_branch(request, current_user)
    if not branch:
        response = jsonify({'error': 'Branch is required'})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 400
    
    is_valid, error_msg = verify_branch_access(service, branch, 'Service')
    if not is_valid:
        response = jsonify({'error': error_msg})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 403
    
    service.status = 'inactive'
    service.updated_at = datetime.utcnow()
    service.save()
    response = jsonify({'message': 'Service deleted successfully'})
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

