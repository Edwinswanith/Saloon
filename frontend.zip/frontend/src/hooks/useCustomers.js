import { useQuery } from '@tanstack/react-query'
import { apiGet } from '../utils/api'

export function useCustomers(page = 1, search = '', perPage = 10) {
  return useQuery({
    queryKey: ['customers', page, search, perPage],
    queryFn: async () => {
      const params = new URLSearchParams({ page, per_page: perPage })
      if (search) params.append('search', search)
      const res = await apiGet(`/api/customers?${params}`)
      if (!res.ok) {
        throw new Error(`Failed to fetch customers: ${res.status}`)
      }
      const data = await res.json()
      console.log('[useCustomers] API response:', data)
      return data
    },
    keepPreviousData: true,
    staleTime: 30 * 1000, // 30 seconds
  })
}

