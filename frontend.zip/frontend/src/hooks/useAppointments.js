/**
 * Appointments React Query Hook
 * 
 * Provides cached data fetching for appointments with pagination and filtering
 */
import { useQuery } from '@tanstack/react-query'
import { apiGet } from '../utils/api'

export function useAppointments({
  page = 1,
  perPage = 20,
  customerId = null,
  staffId = null,
  startDate = null,
  endDate = null,
  status = null,
  sortBy = 'appointment_date',
  sortOrder = 'desc',
} = {}) {
  return useQuery({
    queryKey: ['appointments', page, perPage, customerId, staffId, startDate, endDate, status, sortBy, sortOrder],
    queryFn: async () => {
      const params = new URLSearchParams({
        page: page.toString(),
        per_page: perPage.toString(),
        sort_by: sortBy,
        sort_order: sortOrder,
      })
      if (customerId) params.append('customer_id', customerId)
      if (staffId) params.append('staff_id', staffId)
      if (startDate) params.append('start_date', startDate)
      if (endDate) params.append('end_date', endDate)
      if (status) params.append('status', status)
      
      const res = await apiGet(`/api/appointments?${params}`)
      if (!res.ok) throw new Error('Failed to fetch appointments')
      const data = await res.json()
      // Handle both old format (array) and new format (object with data)
      if (Array.isArray(data)) {
        return { data, pagination: { total: data.length, page: 1, per_page: data.length, pages: 1 } }
      }
      return data
    },
    staleTime: 1 * 60 * 1000, // 1 minute (appointments change frequently)
    cacheTime: 3 * 60 * 1000, // 3 minutes
    keepPreviousData: true,
  })
}

