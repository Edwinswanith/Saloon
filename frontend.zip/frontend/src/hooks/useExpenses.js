/**
 * Expenses React Query Hook
 * 
 * Provides cached data fetching for expenses with pagination and filtering
 */
import { useQuery } from '@tanstack/react-query'
import { apiGet } from '../utils/api'

export function useExpenses({
  page = 1,
  perPage = 20,
  categoryId = null,
  paymentMode = null,
  startDate = null,
  endDate = null,
  search = '',
  sortBy = 'expense_date',
  sortOrder = 'desc',
} = {}) {
  return useQuery({
    queryKey: ['expenses', page, perPage, categoryId, paymentMode, startDate, endDate, search, sortBy, sortOrder],
    queryFn: async () => {
      const params = new URLSearchParams({
        page: page.toString(),
        per_page: perPage.toString(),
        sort_by: sortBy,
        sort_order: sortOrder,
      })
      if (categoryId) params.append('category_id', categoryId)
      if (paymentMode) params.append('payment_mode', paymentMode)
      if (startDate) params.append('start_date', startDate)
      if (endDate) params.append('end_date', endDate)
      if (search) params.append('search', search)
      
      const res = await apiGet(`/api/expenses?${params}`)
      if (!res.ok) throw new Error('Failed to fetch expenses')
      const data = await res.json()
      // Handle both old format (array) and new format (object with data)
      if (Array.isArray(data)) {
        return { data, pagination: { total: data.length, page: 1, per_page: data.length, pages: 1 } }
      }
      return data
    },
    staleTime: 2 * 60 * 1000, // 2 minutes
    cacheTime: 5 * 60 * 1000, // 5 minutes
    keepPreviousData: true,
  })
}

