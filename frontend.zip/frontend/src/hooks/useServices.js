import { useQuery } from '@tanstack/react-query'
import { apiGet } from '../utils/api'

export function useServices(page = 1, perPage = 20, filters = {}) {
  return useQuery({
    queryKey: ['services', page, perPage, filters],
    queryFn: async () => {
      const params = new URLSearchParams({ page, per_page: perPage })
      for (const key in filters) {
        if (filters[key]) params.append(key, filters[key])
      }
      const res = await apiGet(`/api/services?${params}`)
      if (!res.ok) {
        throw new Error(`Failed to fetch services: ${res.status}`)
      }
      const data = await res.json()
      console.log('[useServices] API response:', data)
      // Handle both new format {data, pagination} and legacy format {services: [...]}
      if (data.services && Array.isArray(data.services)) {
        return { 
          data: data.services, 
          pagination: { 
            total: data.services.length, 
            page, 
            per_page: perPage, 
            pages: 1 
          } 
        }
      }
      return data
    },
    keepPreviousData: true,
    staleTime: 30 * 1000, // 30 seconds
  })
}

