import { useQuery } from '@tanstack/react-query'
import { apiGet } from '../utils/api'

export function useProducts(page = 1, perPage = 20, filters = {}) {
  return useQuery({
    queryKey: ['products', page, perPage, filters],
    queryFn: async () => {
      const params = new URLSearchParams({ page, per_page: perPage })
      for (const key in filters) {
        if (filters[key]) params.append(key, filters[key])
      }
      const res = await apiGet(`/api/products?${params}`)
      if (!res.ok) {
        throw new Error(`Failed to fetch products: ${res.status}`)
      }
      const data = await res.json()
      console.log('[useProducts] API response:', data)
      // Handle both new format {data, pagination} and legacy format (array)
      if (Array.isArray(data)) {
        return { data, pagination: { total: data.length, page, per_page: perPage, pages: 1 } }
      }
      return data
    },
    keepPreviousData: true,
    staleTime: 30 * 1000, // 30 seconds
  })
}

