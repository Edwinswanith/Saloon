/**
 * Dashboard React Query Hooks
 *
 * These hooks provide cached data fetching for dashboard components.
 * Data is automatically cached and deduplicated across components.
 *
 * Usage:
 *   const { data, isLoading, error } = useDashboardStats(startDate, endDate, branch)
 */

import { useQuery } from '@tanstack/react-query'
import { apiGet } from '../utils/api'

/**
 * Fetch dashboard statistics
 * Cached for 60 seconds to reduce API calls
 */
export function useDashboardStats(startDate, endDate, branch, enabled = true) {
  return useQuery({
    queryKey: ['dashboard', 'stats', startDate, endDate, branch?.id],
    queryFn: async () => {
      const params = new URLSearchParams()
      if (startDate) params.append('start_date', startDate)
      if (endDate) params.append('end_date', endDate)
      const res = await apiGet(`/api/dashboard/stats?${params}`)
      if (!res.ok) throw new Error('Failed to fetch dashboard stats')
      return res.json()
    },
    staleTime: 60 * 1000,       // 60 seconds
    cacheTime: 5 * 60 * 1000,   // 5 minutes
    enabled: enabled,
  })
}

/**
 * Fetch staff performance data
 * Cached for 60 seconds
 */
export function useStaffPerformance(startDate, endDate, branch, enabled = true) {
  return useQuery({
    queryKey: ['dashboard', 'staff-performance', startDate, endDate, branch?.id],
    queryFn: async () => {
      const params = new URLSearchParams()
      if (startDate) params.append('start_date', startDate)
      if (endDate) params.append('end_date', endDate)
      const res = await apiGet(`/api/dashboard/staff-performance?${params}`)
      if (!res.ok) throw new Error('Failed to fetch staff performance')
      return res.json()
    },
    staleTime: 60 * 1000,
    cacheTime: 5 * 60 * 1000,
    enabled: enabled,
  })
}

/**
 * Fetch top customers data
 * Cached for 60 seconds
 */
export function useTopCustomers(startDate, endDate, branch, limit = 10) {
  return useQuery({
    queryKey: ['dashboard', 'top-customers', startDate, endDate, branch?.id, limit],
    queryFn: async () => {
      const params = new URLSearchParams()
      if (startDate) params.append('start_date', startDate)
      if (endDate) params.append('end_date', endDate)
      params.append('limit', limit)
      const res = await apiGet(`/api/dashboard/top-customers?${params}`)
      if (!res.ok) throw new Error('Failed to fetch top customers')
      return res.json()
    },
    staleTime: 60 * 1000,
    cacheTime: 5 * 60 * 1000,
  })
}

/**
 * Fetch top offerings (services/products) data
 * Cached for 60 seconds
 */
export function useTopOfferings(startDate, endDate, branch, limit = 10) {
  return useQuery({
    queryKey: ['dashboard', 'top-offerings', startDate, endDate, branch?.id, limit],
    queryFn: async () => {
      const params = new URLSearchParams()
      if (startDate) params.append('start_date', startDate)
      if (endDate) params.append('end_date', endDate)
      params.append('limit', limit)
      const res = await apiGet(`/api/dashboard/top-offerings?${params}`)
      if (!res.ok) throw new Error('Failed to fetch top offerings')
      return res.json()
    },
    staleTime: 60 * 1000,
    cacheTime: 5 * 60 * 1000,
  })
}

/**
 * Fetch revenue breakdown data
 * Cached for 60 seconds
 */
export function useRevenueBreakdown(startDate, endDate, branch) {
  return useQuery({
    queryKey: ['dashboard', 'revenue-breakdown', startDate, endDate, branch?.id],
    queryFn: async () => {
      const params = new URLSearchParams()
      if (startDate) params.append('start_date', startDate)
      if (endDate) params.append('end_date', endDate)
      const res = await apiGet(`/api/dashboard/revenue-breakdown?${params}`)
      if (!res.ok) throw new Error('Failed to fetch revenue breakdown')
      return res.json()
    },
    staleTime: 60 * 1000,
    cacheTime: 5 * 60 * 1000,
  })
}

/**
 * Fetch alerts data
 * Cached for 2 minutes
 */
export function useAlerts(branch, enabled = true) {
  return useQuery({
    queryKey: ['dashboard', 'alerts', branch?.id],
    queryFn: async () => {
      const res = await apiGet('/api/dashboard/alerts')
      if (!res.ok) throw new Error('Failed to fetch alerts')
      return res.json()
    },
    staleTime: 2 * 60 * 1000,   // 2 minutes
    cacheTime: 5 * 60 * 1000,
    enabled: enabled,
  })
}

/**
 * Fetch top performer data (company-wide)
 * Cached for 60 seconds
 */
export function useTopPerformer(branch, enabled = true) {
  return useQuery({
    queryKey: ['dashboard', 'top-performer', branch?.id],
    queryFn: async () => {
      const today = new Date()
      const currentMonthStart = new Date(today.getFullYear(), today.getMonth(), 1)
      const params = new URLSearchParams({
        start_date: currentMonthStart.toISOString().split('T')[0],
        end_date: today.toISOString().split('T')[0],
      })
      const res = await apiGet(`/api/dashboard/top-performer?${params}`)
      if (!res.ok) throw new Error('Failed to fetch top performer')
      return res.json()
    },
    staleTime: 60 * 1000,
    cacheTime: 5 * 60 * 1000,
    enabled: enabled,
  })
}

/**
 * Fetch staff leaderboard data
 * Cached for 60 seconds
 */
export function useStaffLeaderboard(branch, enabled = true) {
  return useQuery({
    queryKey: ['dashboard', 'staff-leaderboard', branch?.id],
    queryFn: async () => {
      const res = await apiGet('/api/dashboard/staff-leaderboard')
      if (!res.ok) throw new Error('Failed to fetch staff leaderboard')
      return res.json()
    },
    staleTime: 60 * 1000,
    cacheTime: 5 * 60 * 1000,
    enabled: enabled,
  })
}

/**
 * Fetch client funnel data
 * Cached for 60 seconds
 */
export function useClientFunnel(startDate, endDate, branch) {
  return useQuery({
    queryKey: ['dashboard', 'client-funnel', startDate, endDate, branch?.id],
    queryFn: async () => {
      const params = new URLSearchParams()
      if (startDate) params.append('start_date', startDate)
      if (endDate) params.append('end_date', endDate)
      const res = await apiGet(`/api/dashboard/client-funnel?${params}`)
      if (!res.ok) throw new Error('Failed to fetch client funnel')
      return res.json()
    },
    staleTime: 60 * 1000,
    cacheTime: 5 * 60 * 1000,
  })
}
