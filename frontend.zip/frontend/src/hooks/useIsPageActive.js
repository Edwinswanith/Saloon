/**
 * Custom hook to detect if the current page is active
 * 
 * Since App.jsx uses conditional rendering (components only render when activePage matches),
 * if a component is mounted, it IS the active page. However, we use this hook to ensure
 * data fetching only happens when the component is actually visible and ready.
 * 
 * @param {string} pageName - The name of the page to check (e.g., 'dashboard', 'quick-sale')
 * @returns {boolean} - True if the page should fetch data (component is mounted and active)
 * 
 * Usage:
 *   const shouldFetch = useIsPageActive('dashboard')
 *   useEffect(() => {
 *     if (shouldFetch) {
 *       fetchData()
 *     }
 *   }, [shouldFetch])
 */

import { useState, useEffect } from 'react'

export function useIsPageActive(pageName) {
  const [shouldFetch, setShouldFetch] = useState(false)
  
  useEffect(() => {
    // Since App.jsx uses conditional rendering (components only render when activePage matches),
    // if this component is mounted, it IS the active page.
    // Set shouldFetch to true to allow data fetching.
    setShouldFetch(true)
    
    return () => {
      // When component unmounts, it's no longer active
      setShouldFetch(false)
    }
  }, [])
  
  // Listen for page navigation events as an additional check
  useEffect(() => {
    const handlePageChange = (event) => {
      if (event.detail && event.detail.page) {
        setShouldFetch(event.detail.page === pageName)
      }
    }
    
    window.addEventListener('navigateToPage', handlePageChange)
    return () => window.removeEventListener('navigateToPage', handlePageChange)
  }, [pageName])
  
  return shouldFetch
}

