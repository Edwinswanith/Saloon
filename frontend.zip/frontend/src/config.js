// API Configuration
export const API_BASE_URL = 'http://localhost:5000';
// export const API_BASE_URL = 'https://saloon-management-system-895210689446.europe-west2.run.app';

 